library(testthat)
library(zzedc)

test_check("zzedc")
